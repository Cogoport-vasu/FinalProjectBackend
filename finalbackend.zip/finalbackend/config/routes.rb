Rails.application.routes.draw do
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
  #Article API's
  get "/articles/show", to: "articles#showall"
  get "/articles/show/:id", to: "articles#show"
  post "/articles/addarticle", to: "articles#add"
  put "/articles/editarticle/:id", to: "articles#edit"
  delete "/articles/delete/:id", to: "articles#del"


  #Category API's
  get "/category/show", to:  "categories#showall"
  post "/category", to: "categories#searchadd"
  get "/category/show/:id", to: "categories#showid"
  #post "category/show/name", to: "categories#showname"
  post "/category/filter", to: "categories#filter"

  
  resources :users
  post '/auth/login', to: 'authentication#login'

  post '/signup', to: 'users#create'
  get '/auth/user/:id', to: 'users#create'
  #post "/user/adduser", to: "user#add"
  #get "/users/show", to: "users#index"
  get '/users/show/:id', to: "users#show"   
  post "/users/filter", to: "users#filter"
  put "/users/editprofile/:id", to: "users#update"
  post "/users/articles/:id", to: "users#articleslist"
end
