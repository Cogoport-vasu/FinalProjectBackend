class UsersController < ApplicationController
    skip_before_action :authenticate_request, only: [:create, :index, :filter, :articleslist]
    before_action :set_user, only: [:destroy, :update, :show]
    

    def articleslist
        @users=User.find(params[:id])
        if @users.present?
            render json: @users.articles
        end
    end

    def filter
        search=params[:u_name]
        if search==""
            @users=User.all
        end
        if search!=""
            @users=User.where("name LIKE ?", "#{search}%")
        end
        render json: @users
    end
    
    def index
        @users=User.all
        render json: @users, status: :ok
    end

    def show
        render json: @user, status: :ok
    end

    def create
        @user= User.new(user_params)
        if @user.save
            render json: @user, status: :ok
        else
            render json: { errors: @user.errors.full_messages }, 
                   status: :unprocessable_entity
        end
    end

    def update
#        unless @user.update(user_params)
#            render json: { errors: @user.errors.full_messages }, 
#                   status: :unprocessable_entity
#        end
         #puts params[:id]
         #puts @current_user.id
         @user=User.find(params[:id])
         if @user.id==@current_user.id
            @user.update(name: params[:name],dob: params[:dob],phone: params[:phone],gender: params[:gender],description: params[:description])
            render json: @user
         else
            render html: "Access Denied"
         end
    end

    def destroy
        @user.destroy
    end

    private
#        def edit_user_params
 #           params.permit(:name, :dob, :phone, :gender, :description)
  #      end
        def user_params
            params.permit(:name, :username, :email, :password, :dob, :phone, :gender, :description)
        end

        def set_user
            @user = User.find(params[:id])
        end
end


                    

