class CategoriesController < ApplicationController
    before_action :authenticate_request, except: [:showall, :showid, :searchadd, :filter]

    def showall
        @categories=Category.all
        render json: @categories
    end

    def showid
        @categories=Category.find(params[:id])
        render json: @categories
    end

#    def showname
#        @categories=Category.where(category_name: params[:c_name])
 #       render json: @categories
 #   end

    def searchadd
        if params[:c_name]!=""
            @categories=Category.where(["category_name=?",params[:c_name]])
            if @categories==[]
                @categories=Category.create(category_name: params[:c_name])
            end
        end
        render json: @categories
    end

    def filter
        search=params[:c_name]
        if search==""
            @categories=Category.all
        end
        if search!=""
            @categories=Category.where("category_name LIKE ?", "#{search}%")
        end
        render json: @categories
    end
end
