class ArticlesController < ApplicationController
    before_action :authenticate_request, except: [:showall]

    #GET /articles/showall
    def showall
        @articles=Article.all
        render json: @articles
    end

    #GET /articles/show/:id
    def show
        @articles=Article.find(params[:id])
        render json: @articles
    end

    #POST/articles
    def add
        @categories=Category.find_by(id: params[:category_id])
        if @categories.present?
            @articles=Article.create(title: params[:title], content: params[:content],category_id: params[:category_id],user_id: params[:user_id],imageurl: params[:imageurl] )
            render json:@articles
        elsif
            render html: "category does not exist"
        end
    end

    def edit
        @articles=Article.find(params[:id])
        if @articles.present?
            if @articles.user_id==@current_user.id
                @articles.update(title: params[:title],content: params[:content],imageurl: params[:imageurl])
            end
            render json: @articles
        else
            render html: "Article not present"
        end
    end

    #DELETE /articles/delete/:id
    def del
        @articles=Article.find(params[:id])
        if @articles.present?
            if @articles.user_id==@current_user.id
                Article.destroy(params[:id])
                render html: "Article Deleted"
            end
        else
            render html: "Article not present"
        end
    end
end
